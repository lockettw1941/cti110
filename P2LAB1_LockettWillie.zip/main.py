''' Type your code here. '''

gas_efficiency = 30.0
gas_cost = 3.8999
per_mile = gas_cost / gas_efficiency
ten_mile = per_mile * 20
fifty_mile = per_mile * 75
forth_mile = per_mile * 500
print(f'{ten_mile:.2f} {fifty_mile:2f} {forth_mile:.2f}')


